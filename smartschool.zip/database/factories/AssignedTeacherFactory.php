<?php

namespace Database\Factories;

use App\Models\AssignedTeacher;
use Illuminate\Database\Eloquent\Factories\Factory;

class AssignedTeacherFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = AssignedTeacher::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
